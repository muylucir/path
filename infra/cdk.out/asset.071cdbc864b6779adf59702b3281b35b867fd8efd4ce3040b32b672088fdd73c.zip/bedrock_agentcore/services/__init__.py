"""External service integrations for BedrockAgentCore Runtime SDK."""
